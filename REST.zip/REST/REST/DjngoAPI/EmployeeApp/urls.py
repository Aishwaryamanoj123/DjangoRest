# from django.conf.urls import url
from django.urls import path
from . import views

urlpatterns = [
    path('department/', views.departmentApi),
    # url('department/([0-9]+)', views.departmentApi),
    path('department/<int:id>/', views.departmentApi),
    
]